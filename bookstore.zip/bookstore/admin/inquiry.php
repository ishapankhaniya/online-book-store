	
<?php

 	$con=mysqli_connect("localhost","root","","book");
	
	if($con)
	{
		
		$sql = "SELECT * FROM `contact`";
		
		$result = mysqli_query($con,$sql);
		

if(mysqli_num_rows($result)>0)
 {
 
	echo "<table border='1'>
	<tr>
	<td>name</td>
 	<td>email</td>
 	<td>phone number</td>
 	<td>issue</td>
 	 	</tr>";

	while ($row = mysqli_fetch_array($result))
 	{
		echo "<tr>";
			 //echo "<TD><a href=\"booking.php? busname= {$row['bus_name']}\">".$row['bus_name']."</a></TD>";
         	echo "<td>".$row['name']."</td>";
         	echo "<td>".$row['email']."</td>";
         	echo "<td>".$row['phone']."</td>";
         	echo "<td>".$row['msg']."</td>";
         	//echo "<td>".rtrim($row['time'],"0.")."  HH:MM:SS"."</td>";
      		echo "</tr>";
 }
 echo "</table>";

 	else
		{
			echo "no matching record find";
		}
		}
			mysqli_close($con);
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>css</title>
	<style type="text/css"> 
	body{background-image:url("images/banner.jpg"); color:white;text-align:center;width: 5px;height: 100px;font-style: italic;}

</body>
</html>