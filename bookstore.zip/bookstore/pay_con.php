<?php 

if(isset($_POST['insert']))
{
	$conn= mysqli_connect("localhost","root","");
	if($conn)
	{
				mysqli_select_db($conn,"book");

		$firstname=strval($_POST['name']);
		$lastname=strval($_POST['number']);
		$email=strval($_POST['cvv']);
		$utype=strval($_POST['edate']);
		//$password= md5($passw);
		
		
		$insert="INSERT INTO `payment`(`name`, `c_number`, `cvv`,`e_date`)values('$firstname','$lastname','$email','$utype')";
		if(mysqli_query($conn,$insert))
		{
			  header('Location:recipt.php');
			//echo "record sucessfully...<br/>";
		}
		else
		{
			
			echo "record not sucessful...<br/>";
		}
		mysqli_close($conn);

	}
}
?>