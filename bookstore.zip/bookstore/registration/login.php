<?php 
session_start();
	$conn=mysqli_connect("localhost","root","");
	if($conn)
	{
		mysqli_select_db($conn,"books");

		$email = $_POST['email'];
		$password = $_POST['password'];
		//$pass=md5($password);

		$sql = "select * from regi where email='$email' AND pass='$password'";
		$result =  mysqli_query($conn,$sql);

		if(mysqli_num_rows($result) > 0)
		{
			while ($row = mysqli_fetch_array($result))
			 {
				$_SESSION['username'] = $row['user_nm'];
				$_SESSION['user_id'] = $row['u_id'];
			}
			header('location:../index.php');
		}
		
	
	// else{
	// 	$sql = "select * from admin_regi where email='$email' AND password='$password'";
	// 	$result =  mysqli_query($conn,$sql);
	// 	echo "result";
	// 	if(mysqli_num_rows($result) > 0)
	// 	{
	// 		while ($row = mysqli_fetch_array($result))
	// 		 {
	// 			$_SESSION['username'] = $row['unm'];
	// 		}
	// 		header('location:admin/index_admin.php');
	// 	}
	 	else
		{
			$_SESSION['error'] = "Ooops....invalid user name and password";
			header('location: ../index.php');
		}
	}

	
