<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Animated Login Form template Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login sign up Responsive web template, SmartPhone Compatible web template, free Web Designs for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href='css/bootstrap.min.css' media='all' rel='stylesheet'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="css/animate.min.css"> 
<!-- //Custom Theme files -->
<!-- web font -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'><!--web font-->
<!-- //web font --> 
</head>
<body>
	<!-- main-agileits -->
	<div class="agileits">
		<h1>Animated Add Video detail Form</h1>
		<div class="w3-agileits-info">
			<form class='form animate-form' id='form1' action="insert_video.php" method="POST">
				<p class="w3agileits">Add video Here</p>
				<div class='form-group has-feedback w3ls'>
					<label class='control-label sr-only' for='username'>Username</label> 
					<input class='form-control' id='username' name='url' placeholder='Url' type='text'>
					<span class='glyphicon glyphicon-ok form-control-feedback'></span>
				</div>
				<div class='form-group has-feedback wthree'>
					<label class='control-label sr-only' for='email'>Email address</label> 
					<input class='form-control' id='email' name='title' placeholder='video title' type='text'><span class='glyphicon glyphicon-ok form-control-feedback'></span>
				</div>
				<div class='form-group has-feedback agile'>
					<label class='control-label sr-only' for='email'>Email address</label> 
				<select class='form-control' required="" name="language" style="width: 50%">
			<option selected="" value="">none</option>
			<option value="css">css</option>
			<option value="c">c</option>
			<option value="cpp">cpp</option>
			<!--<option value="css">css</option>-->
			<option value="html">html</option>
			<option value="java">java</option>
			<option value="php">php</option>
			<option value=".net">.net</option>
		</select>
		<span class='glyphicon glyphicon-ok form-control-feedback'></span>
	</div>

				<div class='form-group has-feedback agile'>
					<label class='control-label sr-only' for='password'>upload_dt</label> 
					<input class='form-control w3l' id='password' name='upload_dt' placeholder='Password' type='date'><span class='glyphicon glyphicon-ok form-control-feedback'></span>
				</div>
				<div class='submit w3-agile'>
					<input class='btn btn-lg' type='submit' name="insert" value='SUBMIT'>
				</div>
			</form>
		</div>	
	</div>	
	<!-- //agileits -->
	
	<!-- js -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<script src='js/jquery.validate.min.js'></script>
	<script src='js/formAnimation.js'></script>
	<script src='js/shake.js'></script> 
	<!-- //js -->
</body>
</html>