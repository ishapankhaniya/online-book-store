	<?php 

session_start();
$con=mysqli_connect("localhost","root","","book");


if(isset($_REQUEST['bid'])){

$cid =  $_SESSION['id'];
$bid = $_REQUEST['bid'];
$sql = "INSERT INTO `cart`(`regi_id`, `b_id`) VALUES ($cid,$bid)";

mysqli_query($con,$sql);

//$_SESSION['msg'] = 'Product Added';

}

?>