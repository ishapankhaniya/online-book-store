<?php 
echo "hello";
 	if(isset($_POST['insert']))
 	{
 		$con=mysqli_connect("localhost","root","");
 		if($con)
 		{
 			echo "mysql connection <br>";
 			mysqli_select_db($con,"toy");

 			$unm=($_POST['username']);
 			$email=($_POST['email']);
 			$pass=($_POST['password']);
 			$dob=($_POST['dob']);
 			$add=($_POST['add']);
 			$city=($_POST['city']);
 			$cno=($_POST['cno']);
 				//$ lan="SELECT * from `language` WHERE `lang`= '$language'";
 				// echo $lan;
 				// $resul =  mysqli_query($con,$lan);
 				//while ($res = mysqli_fetch_array($resul)) {
 					# code...
 				//	$result = $res['lang_id'];
 				//}
 				// echo $result['lang_id'];
 				
 			$insert="INSERT INTO `regi`(`user_nm`,`email`,`password`,`dob`,`address`,`city`,`contact`)
 								  values('$unm','$email','$pass','$dob','$add','$city','$cno')";
 								  echo $insert;
 					if(mysqli_query($con,$insert))
 					{
 					
 						echo "<br>record inserted sucessfully...<br>";

 					}
 					else
 					{
 						echo "record not inserted sucessfully....<br>";
 					}
 					mysqli_close($con);


 		}
 	}
 ?>