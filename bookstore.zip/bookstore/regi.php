<?php 
if(isset($_POST['submit']))
{
	//echo "string";
	$conn= mysqli_connect("localhost","root","");
	if($conn)
	{
				mysqli_select_db($conn,"book");
		$email=$_POST['email'];
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$pass=$_POST['password'];
		$add=$_POST['addr'];
		$mn=$_POST['mno'];
		$city=$_POST['city'];
		$pin=$_POST['pno'];
		
				// $email=$_POST['email'];							
		$insert="INSERT INTO `regi`(`email`,`fname`,`lname`,`pass`,`add`,`mn`,`city`,`pin`)values('$email','$fname','$lname','$pass','$add','$mn','$city','$pin')";
		if(mysqli_query($conn,$insert))
		{
			
			 //echo "record sucessfully...<br/>";
			header('Location:index.php');
			//echo "msqli_error($conn)";	
			
		}
		else
		{
			
			echo "record not sucessful...<br/>";
		}
		mysqli_close($conn);

	}
}
?>