<?php include "index.php"?>
							 
			
							<?php
                                        $con=mysqli_connect("localhost","root","");
                                        if($con)
                                        {
                                        mysqli_select_db($con,"books");
                                            $res="SELECT * FROM `book_d` WHERE c_id=1";
                                            $sql=mysqli_query($con,$res);
                                            if(mysqli_num_rows($sql)>0)
                                            {
                                                while($row=mysqli_fetch_array($sql))
                                                {
                                                    $url=$row['url']; 
                                                    $abc=$row['des'];?>
               		<!-- card group  -->
					<!--  <div class="card-group">
 -->

	 					<!-- //card -->

	 <!-- <div class=" col-lg-9 mt-lg-0 mt-5 right-product-grid">
						 --><div class=" img-right col-lg-3 mt-5 col-sm-6 p-0">
							<!-- card -->
							<div class="card product-men p-3">
								<div class="men-thumb-item">
									<img src="<?php echo"images/$url"?>"  alt="" class="card-img-top">
									<div class="men-cart-pro">
										<div class="inner-men-cart-pro">
											<a href="mens.html" class="link-product-add-cart">Quick View</a>
										</div>
									</div>
								</div>
								<!-- card body -->
								<div class="card-body  py-3 px-2">
									<h5 class="card-title text-capitalize">Solid Formal Green Shirt</h5>
									<div class="card-text d-flex justify-content-between">
										<p class="text-dark font-weight-bold">$18.99</p>
										<p class="line-through">$24.99</p>
									</div>
								</div>
								<!-- card footer -->
								<div class="card-footer d-flex justify-content-end">
									<form action="#" method="post">
										<input type="hidden" name="cmd" value="_cart">
										<input type="hidden" name="add" value="1">
										<input type="hidden" name="hub_item" value="Solid Formal Green Shirt">
										<input type="hidden" name="amount" value="18.99">
										<button type="submit" class="hub-cart phub-cart btn">
											<i class="fa fa-cart-plus" aria-hidden="true"></i>
										</button>
										<a href="#" data-toggle="modal" data-target="#myModal1"></a>
									</form>
								</div>
							</div>
						</div>
					<?php } } } ?>
						<!-- //card -->
						<!-- card -->