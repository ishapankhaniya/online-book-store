 <li class="nav-item dropdown has-mega-menu" style="position:static;">
                            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"style=" top:5px;left:220px;position:absolute;" > | Author</a>
                            <div class="dropdown-menu" style="width:100%">
                                <div class="container">
                                    <div class="row w3_kids  py-3">
                                        <div class="col-md-3 ">
                                            <span class="bg-light">Biographi books author</span>
                                              <a class="dropdown-item" href="swami.php">Swami vivekanand</a> 
                                               <a class="dropdown-item" href="kalam.php">APJ kalam</a> 
                                          <!--  <a class="dropdown-item" href="boys.html">T-Shirts</a>
                                            <a class="dropdown-item" href="boys.html">Coats</a>
                                            <a class="dropdown-item" href="boys.html">Shirts</a>
                                            <a class="dropdown-item" href="boys.html">Suits & Blazers</a>
                                            <a class="dropdown-item" href="boys.html">Jackets</a>
                                            <a class="dropdown-item" href="boys.html">Trousers</a>-->
                                        </div>
                                        <!--<div class="col-md-3">-->
                                            
                                            <!--<a class="dropdown-item mt-4" href="boys.html">T-Shirts</a>
                                            <a class="dropdown-item" href="boys.html">Coats</a>
                                            <a class="dropdown-item" href="boys.html">Shirts</a>
                                            <a class="dropdown-item" href="boys.html">Suits & Blazers</a>
                                            <a class="dropdown-item" href="boys.html">Jackets</a>
                                            <a class="dropdown-item" href="boys.html">Trousers</a>
                                        </div> -->
                                        <div class="col-md-3">
                                             <span>Software Language books author</span>
                                             <a class="dropdown-item" href="bala.php">E Balagurusamy</a> 
                                             <a class="dropdown-item" href="yash.php">Yashavant Kanetkar</a>
                                              <a class="dropdown-item" href="nageswara.php">Nageswara Rao</a>
                                              <!--  <a class="dropdown-item" href="anholt.php">Laurence anholt</a>-->
                                             <!-- <a class="dropdown-item" href="elliot.php">Elliot Koffman</a>-->
                                            <!--  <a class="dropdown-item" href="jb.php">J B Rainsberger</a>--> 
                                           <!--  <a class="dropdown-item" href="girls.html">T-shirts</a>
                                            <a class="dropdown-item" href="girls.html">Dresses</a>
                                            <a class="dropdown-item" href="girls.html">Tunics</a>
                                            <a class="dropdown-item" href="girls.html">Skirts</a>
                                            <a class="dropdown-item" href="girls.html">Jeans</a>
                                            <a class="dropdown-item" href="girls.html">Midi</a> -->
                                        </div>
                                         <div class="col-md-3">
                                            <span>Story books author</span>
                                            <a class="dropdown-item" href="anholt.php">Laurence anholt</a>
                                             <a class="dropdown-item" href="john.php">John steinbeck</a>
                                            <!--<a class="dropdown-item  mt-4" href="girls.html">Tunics</a>
                                            <a class="dropdown-item" href="girls.html">Skirts</a>
                                            <a class="dropdown-item" href="girls.html">T-shirts</a>
                                            <a class="dropdown-item" href="girls.html">Dresses</a>
                                            <a class="dropdown-item" href="girls.html">Jeans</a>
                                        </div> -->
                                    </div>

                                    <div class="col-md-3">
                                            <span>novelist books author</span>
                                            <a class="dropdown-item" href="lisa.php">lisa see</a>
                                            <a class="dropdown-item" href="toni.php">toni morrison</a>
                                             <a class="dropdown-item" href="ken.php">ken follett</a>
                                            <!--<a class="dropdown-item  mt-4" href="girls.html">Tunics</a>
                                            <a class="dropdown-item" href="girls.html">Skirts</a>
                                            <a class="dropdown-item" href="girls.html">T-shirts</a>
                                            <a class="dropdown-item" href="girls.html">Dresses</a>
                                            <a class="dropdown-item" href="girls.html">Jeans</a>
                                        </div> -->
                                    </div>
                                </div>
                            </div>
                        </li>