<?php
session_start();
$con=mysqli_connect("localhost","root","");
	if($con)
	{
		mysqli_select_db($con,"book");
		$username=$_SESSION['username'];
		$user=$_SESSION['id'];
		if(isset($username))
		{
			$sql="SELECT * FROM `regi` WHERE fname='$username' ";

			$res=mysqli_query($con,$sql);
			//echo "isha1";
 				if(mysqli_num_rows($res)>0)
               		 {
               		 	while($row=mysqli_fetch_array($res))
               		 	{
               		 		$lname=$row['lname'];
               		 		$fname=$row['fname'];
               		 		$email=$row['email'];
               		 		$add=$row['add'];
               		 		$mn=$row['mn'];
               		 		$city=$row['city'];
               		 		$pin=$row['pin'];
               		 		$pass=$row['pass'];

               		 	}
               		 }	
            
		}
		else
		{
			echo "not show";
		}
	}
	?>
	 <!DOCTYPE html>
<html>
    <head>  
	<meta charset="UTF-8">
		<title> Profile Settings</title>
		<style type="text/css"> 
	body{background-image:url("images/bg-banner.jpg");
</style>
    </head> 
	<body>
		 
		<?php
      if(isset($_SESSION['msg']))
      {
         echo "<div id='lerr'><h4 style='color:red;'>".$_SESSION['msg']."</h4></div>";
         ?>
         <script>
            $(document).ready(function(){
            $('#lerr').relay(1000).fadeOut(1000);
            });
         </script>
         <?php unset($_SESSION['msg']);
      }
    ?>
    <a href="index.php" style="margin-top: -270px;">Back</a>

		<h3 style="text-align:center;">Update Profile Information</h3> 
		       <form method="post" action="update_pro.php?user=<?php echo $user; ?>" style="text-align:center;">            			
					<label >Email:</label><br> 
			         <input type="text" name="email" value="<?php echo $email; ?>" /><br> 
			         <label>First Name:</label><br>
			         <input type="text" name="fname" value="<?php echo $fname; ?>" /><br> 
			         <label>Last Name:</label><br> 
			         <input type="text" name="lname" value="<?php echo $lname; ?>" /><br>
			 		 <label>password:</label><br> 
			         <input type="text" name="pass" value="<?php echo $pass; ?>" /><br>
			         <label>Address:</label><br>          
			         <input type="text" name="add" value="<?php echo $add; ?>" /><br>
					 <label>Phone Number:</label><br>          
			         <input type="text" name="mn" value="<?php echo $mn; ?>" /><br>  
					 <label>City:</label><br>          
			         <input type="text" name="city" value="<?php echo $city; ?>" /><br> 
					 <label>Pin Code:</label><br>          
			         <input type="text" name="pin" value="<?php echo $pin; ?>" /><br><br>    
			         <input type="submit" name="update" value="Update Profile" />        
		</form> 
	</body>
	</html>