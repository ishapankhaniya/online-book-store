 <?php
 session_start();
 					echo "Your receipt";
                	echo "<table border='1'>";

                     	echo "<td>name</td>";
 					 echo "<td>".$_SESSION['username']."</td>";
 					 echo "</tr>";
                     echo "<tr>";
                     //echo "first name";
                      echo "<td>Email</td>";
                     echo "<td>".$_SESSION['email']."</td>";
                     echo "</tr>";

	            	                     echo "<tr>";
                    					 echo "<td>Product Name</td>";
										 echo "<td>price</td>";
					 					echo "</tr>";
								

                             if(isset($_SESSION['id']))
                                 {
                            $uname=$_SESSION['id'];
                            //$bid=$_REQUEST['bid'];
                             $con=mysqli_connect("localhost","root","","book");
                             if($con)
                             {
                            $res="SELECT * FROM `cart` WHERE regi_id = '$uname'";
                             $sql=mysqli_query($con,$res);
                            if(mysqli_num_rows($sql)>0)
                                 {
                                     while($row=mysqli_fetch_array($sql))
                                         {
                                            $bid=$row['b_id'];                                       
                                            $abc="SELECT * FROM `book` WHERE b_id='$bid'";
                                            $xyz=mysqli_query($con,$abc);
                                            //$isha=mysqli_num_rows($xyz)>0;
                                            while ($row1=mysqli_fetch_array($xyz)) {
                                                $url=$row1['url'];
                                                $price=$row1['Price'];
                                                $bname=$row1['Bname'];
	//echo $_SESSION['username'];		 
 					 							echo "<tr>";
 					 //echo "<td>Address</td>";
 					 						echo "<td>".$bname."</td>";
 					 						echo "<td>".$price."</td>";
 					 						echo "</tr>";
 					 							  }}}}}
                     
                   					  echo "</table>";
                       

	?>
			
		
<!DOCTYPE html>
<html>
<head>
	<title>css</title>
	<style type="text/css"> 
	body{background-image:url("images/bg-banner.jpg"); color:white;text-align:center;width: 5px;height: 100px;font-style: italic;}
	a{margin-left: 190px;position: absolute; }
	</style>
</head>
<body>
	<a href="payment.php" style="margin-top: -470px;">Back</a>
	</body>
	
</body>
</html>