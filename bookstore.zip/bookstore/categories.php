 <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Authors
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                           <a class="nav-link" href="<?php echo"product.php?c_id=16";?>">swami vivekanand</a>
                           <a class="nav-link " href="<?php echo"product.php?c_id=11";?>">Balaguruswami</a>
                           <a class="nav-link " href="<?php echo"product.php?c_id=15";?>">John steinbeck</a>
                           <a class="nav-link " href="<?php echo"product.php?c_id=19";?>">Tony morrison</a>
                           <a class="nav-link " href="<?php echo"product.php?c_id=17";?>">APJ kalam</a>
                        </div>
                     </li>
                     <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Categories
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                           <a class="nav-link" href="<?php echo"product.php?c_id=1";?>">Art book</a>
                           <a class="nav-link " href="<?php echo"art.php?c_id=2";?>">Architecture book</a>
                           <a class="nav-link " href="<?php echo"art.php?c_id=3";?>">Cook book</a>
                           <a class="nav-link " href="<?php echo"art.php?c_id=4";?>">Funny book</a>
                           <a class="nav-link " href="<?php echo"art.php?c_id=5";?>">Horror book</a>
                        </div>
                     </li>
                     