<li class="nav-item dropdown has-mega-menu" style="position:static;">
                            <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Categories</a>
                            <div class="dropdown-menu" style="width:100%">
                                <div class="px-0 container">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <a class="dropdown-item" href="art.php">Art Books</a>
                                            <a class="dropdown-item" href="archi.php">Architecture Books</a>
                                            <a class="dropdown-item" href="bio.php">Biographies</a>
                                            
                                        </div>
                                        <div class="col-md-4">
                                            
                                            <a class="dropdown-item" href="cook.php">CookBook,Food Books</a>
                                            <a class="dropdown-item" href="funny.php">Funny Books</a>
                                            <a class="dropdown-item" href="horror.php">Horror Books</a>
                                           
                                        </div>
                                        <div class="col-md-4">
                                            
                                            <a class="dropdown-item" href="medi.php">medical Books</a>
                                            <a class="dropdown-item" href="poly.php">Political Books</a>
                                            <a class="dropdown-item" href="bus.php">Business & Economical Books</a>
                                            <a class="dropdown-item" href="comp.php">Computer & Technology Books</a>
                                        </div>
                                        
                                        
                                    </div>
                                </div>
                            </div>
                        </li>
                        