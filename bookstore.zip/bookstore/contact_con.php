<?php 
session_start();
if(isset($_POST['submit']))
{
	//echo "string";
	$conn= mysqli_connect("localhost","root","");
	if($conn)
	{
				mysqli_select_db($conn,"book");
		$name=$_POST['name'];
		$email=$_POST['email'];
		$phone=$_POST['phone'];
		$msg=$_POST['msg'];
		
				// $email=$_POST['email'];							
		$insert="INSERT INTO `contact`(`name`,`email`,`phone`,`msg`)values('$name','$email','$phone','$msg')";
		if(mysqli_query($conn,$insert))
		{
			
			 //echo "record sucessfully...<br/>";
			header('Location:contact.php');
			$_SESSION['msg']="sucessfully add inquriy";

			//echo "msqli_error($conn)";	
			
		}
		else
		{
			
			echo "record not sucessful...<br/>";
		}
		mysqli_close($conn);

	}
}
?>