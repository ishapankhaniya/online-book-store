<?php 

if(isset($_POST['insert']))
{
	$conn= mysqli_connect("localhost","root","");
	if($conn)
	{
				mysqli_select_db($conn,"book");

		$firstname=strval($_POST['name']);
		$lastname=strval($_POST['mn']);
		$email=strval($_POST['city']);
		$utype=strval($_POST['add_type']);
		//$password= md5($passw);
		
		
		$insert="INSERT INTO `placeor`(`name`, `mn`, `city`,`add_type`)values('$firstname','$lastname','$email','$utype')";
		if(mysqli_query($conn,$insert))
		{
			 header('Location:payment.php');
			//echo "record sucessfully...<br/>";
		}
		else
		{
			
			echo "record not sucessful...<br/>";
		}
		mysqli_close($conn);

	}
}
?>