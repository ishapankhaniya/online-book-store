<?php 
echo "hello";
 	if(isset($_POST['insert']))
 	{
 		$con=mysqli_connect("localhost","root","");
 		if($con)
 		{
 			echo "mysql connection <br>";
 			mysqli_select_db($con,"e_learning");

 			$url=($_POST['url']);
 			$title=($_POST['title']);
 			$language=($_POST['language']);
 			$upload_dt=($_POST['upload_dt']);
 				$lan="SELECT * from `language` WHERE `lang`= '$language'";
 				echo $lan;
 				$resul =  mysqli_query($con,$lan);
 				while ($res = mysqli_fetch_array($resul)) {
 					# code...
 					$result = $res['lang_id'];
 				}
 				// echo $result['lang_id'];
 				
 			$insert="INSERT INTO `video`(`url`,`lang_id`,`title`,`upload_date`)
 								  values('$url','$result','$title','$upload_dt')";
 								  echo $insert;
 					if(mysqli_query($con,$insert))
 					{
 					
 						echo "<br>record inserted sucessfully...<br>";

 					}
 					else
 					{
 						echo "record not inserted sucessfully....<br>";
 					}
 					mysqli_close($con);


 		}
 	}
 ?>