<?php
session_start();
// if(isset($_POST['update']))
// {		
$conn=mysqli_connect("localhost","root","");
	if($conn)
	{
		mysqli_select_db($conn,"book");
			$user=$_GET['user'];
			$email = $_POST['email'];
			$fname = $_POST['fname'];
			$lname = $_POST['lname'];
			$add = $_POST['add'];
			$pass= $_POST['pass'];
			$mn= $_POST['mn'];
			$city= $_POST['city'];
			$pin = $_POST['pin'];
			 $res="UPDATE `regi` SET `email`='$email',`fname`='$fname',`lname`='$lname',`pass`='$pass',`add`='$add',`mn`='$mn',`city`='$city',`pin`='$pin'  WHERE `regi_id`=$user ";
			// echo $res;
			 if(mysqli_query($conn,$res))
			 {

					 	$_SESSION['msg']="YOUR DETAILS UPDATED...";
					 	header('location:edit_pro.php');
					 	//echo "secuss";
			 }

			 //header('location:index.php');
		
 

else
{
	echo"not update";
}
}
//}

?>