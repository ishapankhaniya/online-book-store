<?php
 
	session_start();
	$conn=mysqli_connect("localhost","root","");
	if($conn)
	{
		mysqli_select_db($conn,"book");
		$uname=$_SESSION['username'];
		if(isset($uname))
		{
			 //$res="SELECT * FROM `regi` WHERE fname=$uname";
			 
			 $res="SELECT * FROM `regi` WHERE fname='$uname'";

             $sql=mysqli_query($conn,$res);
             if(mysqli_num_rows($sql)>0)
                {
                	echo "Yourprofile";
                	echo "<table border='1'>";

                   while($row=mysqli_fetch_array($sql))
                     { 
                     	echo "<td>Email</td>";
 					 echo "<td>".$row['email']."</td>";
 					 echo "</tr>";
                     echo "<tr>";
                     //echo "first name";
                      echo "<td>First Name</td>";
                     echo "<td>".$row['fname']."</td>";
                     echo "</tr>";
                     echo "<tr>";
                     echo "<td>Last Name</td>";
					 echo "<td>".$row['lname']."</td>";
					 echo "</tr>";
					 echo "<tr>";					 
 					 echo "<tr>";
 					 echo "<td>Address</td>";
 					 echo "<td>".$row['add']."</td>";
 					 echo "</tr>";
 					 echo "<tr>";
 					 echo "<td>Phone Number</td>";
 					 echo "<td>".$row['mn']."</td>";
 					 echo "</tr>";
 					 echo "<tr>";
 					 echo "<td>City</td>";
					 echo "<td>".$row['city']."</td>";
					 echo "</tr>";
					 echo "<tr>";
					 echo "<td>Pin Code</td>";
					 echo "<td>".$row['pin']."</td>";
					 echo "</tr>";
                     }
                     echo "</table>";
				}
		}

		else 
		{
				
				echo "don't created profile";
	}
}
	?>
			
		
<!DOCTYPE html>
<html>
<head>
	<title>css</title>
	<style type="text/css"> 
	body{background-image:url("images/bg-banner.jpg"); color:white;text-align:center;width: 5px;height: 100px;font-style: italic;}
	a{margin-left: 190px;position: absolute; }
	</style>
</head>
<body>
	<a href="index.php" style="margin-top: -510px;">Back</a>
	<a href="edit_pro.php" style=" margin-left:240px;margin-top:-510px;">Edit</a>
</body>
	
</body>
</html>