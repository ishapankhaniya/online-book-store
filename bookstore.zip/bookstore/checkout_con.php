 <?php
 session_start();
                             if(isset($_SESSION['id']))
                                 {
                            $uname=$_SESSION['id'];
                            //$bid=$_REQUEST['bid'];
                             $con=mysqli_connect("localhost","root","","book");
                             if($con)
                             {
                            $res="SELECT * FROM `cart` WHERE regi_id = '$uname'";
                             $sql=mysqli_query($con,$res);
                            if(mysqli_num_rows($sql)>0)
                                 {
                                     while($row=mysqli_fetch_array($sql))
                                         {
                                            $bid=$row['b_id'];                                       
                                            $abc="SELECT * FROM `book` WHERE b_id='$bid'";
                                            $xyz=mysqli_query($con,$abc);
                                            //$isha=mysqli_num_rows($xyz)>0;
                                            while ($row1=mysqli_fetch_array($xyz)) {
                                                $url=$row1['url'];
                                                $price=$row1['Price'];
                                                $bname=$row1['Bname'];
                                                                                               ?>